#Neil O'Sullivan
#R00206266
#SDH4-C
import math

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import svm, metrics

# Read in csv file
from sklearn.model_selection import KFold, StratifiedKFold

data = pd.read_excel("movie_reviews.xlsx")

training_data = []
training_data_reviews = []
test_data = []
test_data_reviews = []
training_labels = []
test_labels = []
number_positive_training = 0
number_negative_training = 0
number_positive_test = 0
number_negative_test = 0
task3words=[]


def task1():
    #Map split 1=Test, 0 = Training
    data["Split"] = data["Split"].map(lambda x: 1 if x == "test" else 0)

    training_data_reviews = data[data["Split"] == 0][["Review"]]
    training_labels = data[data["Split"] == 0][["Sentiment"]]
    test_data_reviews = data[data["Split"] == 1][["Review"]]
    test_labels = data[data["Split"] == 1][["Sentiment"]]

    #Deep copies to slice again
    test_data = data[data["Split"] == 1].copy(deep=True)
    training_data = data[data["Split"] == 0].copy(deep=True)

    training_data["Sentiment"] = training_data["Sentiment"].map(lambda x: 1 if x == "positive" else 0)

    number_positive_training = training_data[training_data["Sentiment"] == 1][["Sentiment"]].count()
    number_negative_training = training_data[training_data["Sentiment"] == 0][["Sentiment"]].count()

    test_data["Sentiment"] = test_data["Sentiment"].map(lambda x: 1 if x == "positive" else 0)
    number_positive_test = test_data[test_data["Sentiment"] == 1][["Sentiment"]].count()
    number_negative_test = test_data[test_data["Sentiment"] == 0][["Sentiment"]].count()


    #print(training_data)
    #print(training_labels)
    #print(test_data)
    #print(test_labels)
    #print("Number of positive reviews in the training set: ",number_positive_training)
    #print("Number of negative reviews in the training set: ",number_negative_training)
    #print("Number of positive reviews in the test set: ",number_positive_test)
    #print("Number of negative reviews in the test set: ",number_negative_test)
    #print(training_data_reviews)


    return training_data_reviews, training_labels, test_data_reviews, test_labels

def task2(training_data_reviews):

    #Remove special characters
    training_data_reviews = training_data_reviews['Review'].str.replace('[^a-zA-Z0-9]', ' ', regex=True).str.strip()
    #Change to lower case
    training_data_reviews = training_data_reviews.str.lower()

    #Split into individual words
    all_words = training_data_reviews.str.split()

    new_words = []
    for i in all_words:
        new_words += i

    #Input min occurences of word and lenght
    minWordLength = int(input("Enter minimum word lenght:"))
    minWordOccurence = int(input("Enter minimum word occurrence to be printed:"))

    wordOccurences = {}
    words_result=[]

    #Count occurrences of each word
    for word in new_words:
        if (len(word) >= minWordLength):
            if (word in wordOccurences):
                wordOccurences[word] = wordOccurences[word] + 1
            else:
                wordOccurences[word] = 1

    #If word occured more than the minimum occurence add to result list
    for word in wordOccurences:
        if wordOccurences[word] >= minWordOccurence:
            #print(word + ":" + str(wordOccurences[word]))
            words_result.append(word)

    #print(words_result)

    return words_result


def task3(task3words, data_reviews, labels):
    #print(data_reviews)
    wordOccurencesPositive = {}
    wordOccurencesNegative = {}

    for word in task3words:
        wordOccurencesPositive[word] = 0
        wordOccurencesNegative[word] = 0

    for i, review in enumerate(data_reviews["Review"]):
        words = review.split()
        if labels["Sentiment"].values[i] == "positive":
            for word in task3words:
                if word in words:
                    wordOccurencesPositive[word] += 1

        else:
            for word in task3words:
                if word in words:
                    wordOccurencesNegative[word] += 1

        for word in task3words:
            if word not in wordOccurencesPositive:
                wordOccurencesPositive[word] = 0

        for word in task3words:
            if word not in wordOccurencesNegative:
                wordOccurencesNegative[word] = 0

    #print(task3words)
    #print(wordOccurencesNegative)
    #print(wordOccurencesPositive)

    return wordOccurencesPositive, wordOccurencesNegative


def task4(wordOccurencesPositive, wordOccurencesNegative, training_labels):
    total = len(training_labels)  # total number of reviews
    positive = sum(training_labels.iloc[:, 0] == "positive")  # number of positive reviews
    negative = sum(training_labels.iloc[:, 0] == "negative")  # number of negative reviews

    # In[51]:

    prior_pos = positive / total  # positive prior
    prior_neg = negative / total  # negative prior
    alpha = 1  # defining alpha


    likelihood_positive = {}  # creating empty dictionary for P[word in review |positive review]
    likelihood_negative = {}  # creating empty dictionary for P[word in review | negative review]
    for word in wordOccurencesPositive:
        likelihood_positive[word] = (wordOccurencesPositive[word] + alpha) / (
                    positive + alpha * len(wordOccurencesPositive))

    for word in wordOccurencesNegative:
        likelihood_negative[word] = (wordOccurencesNegative[word] + alpha) / (
                    negative + alpha * len(wordOccurencesNegative))


    #likelihood_negative

    print(likelihood_negative)
    print(likelihood_positive)
    return likelihood_negative, likelihood_positive, prior_pos, prior_neg

def task5(review, likelihood_negative, likelihood_positive, prior_pos, prior_neg):
    prediction = []
    words = review.split()
    logLikelihood_positive = 0
    logLikelihood_negative = 0

    for word in words:
        for key, value in likelihood_positive.items():
            if word == key:
                logLikelihood_positive = logLikelihood_positive + math.log(value)

        for key, value in likelihood_negative.items():
            if word == key:
                logLikelihood_negative = logLikelihood_negative + math.log(value)


    if logLikelihood_positive - logLikelihood_negative > math.log(prior_neg) - math.log(prior_pos):
        prediction.append(1)
        print("Positive")
        #if logLikelihood_negative - logLikelihood_positive > math.log(prior_pos) - math.log(prior_neg):
    else:
        prediction.append(0)
        print("Negative")


    print(prediction)
    return prediction


def task6(training_data_reviews, training_labels, likelihood_negative, likelihood_positive, prior_pos, prior_neg):
    skf = StratifiedKFold(n_splits=5)
    accuracies = []

    for train_index, test_index in skf.split(training_data_reviews, training_labels):
        X_train = training_data_reviews[train_index]
        y_train = training_labels[train_index]

        for i in X_train:
            test=task5(training_data_reviews[i], likelihood_negative, likelihood_positive, prior_pos, prior_neg)
            test2=training_labels[test_index]

            print(X_train)
            print(test)
            print(test2)

        #accuracy = accuracy_score(test, test2)
        #accuracies.append(accuracy)

    mean_accuracy = np.mean(accuracies)
    return mean_accuracy




def main():
    training_data_reviews, training_labels, test_data_reviews, test_labels = task1()
    task3words = task2(training_data_reviews)
    wordOccurencesPositive, wordOccurencesNegative = task3(task3words, training_data_reviews, training_labels)
    likelihood_negative, likelihood_positive, prior_pos, prior_neg= task4(wordOccurencesPositive, wordOccurencesNegative, training_labels)
    review= input("Enter new review:")
    task5(review, likelihood_negative, likelihood_positive, prior_pos, prior_neg)
    task6(training_data_reviews, training_labels, likelihood_negative, likelihood_positive, prior_pos, prior_neg)






main()