#Neil O'Sullivan
#R00206266
#SDH4-C

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import svm

# Read in csv file
data = pd.read_excel("movie_reviews.xlsx")

training_data = []
training_data_reviews = []
test_data = []
test_data_reviews = []
training_labels = []
test_labels = []
number_positive_training = 0
number_negative_training = 0
number_positive_test = 0
number_negative_test = 0
task3words=[]


def task1():
    #Map split 1=Test, 0 = Training
    data["Split"] = data["Split"].map(lambda x: 1 if x == "test" else 0)

    training_data_reviews = data[data["Split"] == 0][["Review"]]
    training_labels = data[data["Split"] == 0][["Sentiment"]]
    test_data_reviews = data[data["Split"] == 1][["Review"]]
    test_labels = data[data["Split"] == 1][["Sentiment"]]

    #Deep copies to slice again
    test_data = data[data["Split"] == 1].copy(deep=True)
    training_data = data[data["Split"] == 0].copy(deep=True)

    training_data["Sentiment"] = training_data["Sentiment"].map(lambda x: 1 if x == "positive" else 0)

    number_positive_training = training_data[training_data["Sentiment"] == 1][["Sentiment"]].count()
    number_negative_training = training_data[training_data["Sentiment"] == 0][["Sentiment"]].count()

    test_data["Sentiment"] = test_data["Sentiment"].map(lambda x: 1 if x == "positive" else 0)
    number_positive_test = test_data[test_data["Sentiment"] == 1][["Sentiment"]].count()
    number_negative_test = test_data[test_data["Sentiment"] == 0][["Sentiment"]].count()


    #print(training_data)
    #print(training_labels)
    #print(test_data)
    #print(test_labels)
    #print("Number of positive reviews in the training set: ",number_positive_training)
    #print("Number of negative reviews in the training set: ",number_negative_training)
    #print("Number of positive reviews in the test set: ",number_positive_test)
    #print("Number of negative reviews in the test set: ",number_negative_test)
    #print(training_data_reviews)


    return training_data_reviews, training_labels, test_data_reviews, test_labels

def task2(training_data_reviews):

    #Remove special characters
    training_data_reviews = training_data_reviews['Review'].str.replace('[^a-zA-Z0-9]', ' ', regex=True).str.strip()
    #Change to lower case
    training_data_reviews = training_data_reviews.str.lower()

    #Split into individual words
    all_words = training_data_reviews.str.split()

    new_words = []
    for i in all_words:
        new_words += i

    #Input min occurences of word and lenght
    minWordLength = int(input("Enter minimum word lenght:"))
    minWordOccurence = int(input("Enter minimum word occurrence to be printed:"))

    wordOccurences = {}
    words_result=[]

    #Count occurrences of each word
    for word in new_words:
        if (len(word) >= minWordLength):
            if (word in wordOccurences):
                wordOccurences[word] = wordOccurences[word] + 1
            else:
                wordOccurences[word] = 1

    #If word occured more than the minimum occurence add to result list
    for word in wordOccurences:
        if wordOccurences[word] >= minWordOccurence:
            #print(word + ":" + str(wordOccurences[word]))
            words_result.append(word)

    #print(words_result)

    return words_result


def task3(task3words, data_reviews, labels):
    #print(data_reviews)
    wordOccurencesPositive = {}
    wordOccurencesNegative = {}

    for word in task3words:
        wordOccurencesPositive[word] = 0
        wordOccurencesNegative[word] = 0

    for i, review in enumerate(data_reviews["Review"]):
        words = review.split()
        if labels["Sentiment"].values[i] == "positive":
            for word in task3words:
                if word in words:
                    wordOccurencesPositive[word] += 1

        else:
            for word in task3words:
                if word in words:
                    wordOccurencesNegative[word] += 1

        for word in task3words:
            if word not in wordOccurencesPositive:
                wordOccurencesPositive[word] = 0

        for word in task3words:
            if word not in wordOccurencesNegative:
                wordOccurencesNegative[word] = 0

    #print(task3words)
    print(wordOccurencesNegative)
    print(wordOccurencesPositive)

    return wordOccurencesPositive, wordOccurencesNegative


def task4(wordOccurencesPositive, wordOccurencesNegative):
    alpha = 1
    result={}




def main():
    training_data_reviews, training_labels, test_data_reviews, test_labels = task1()
    task3words = task2(training_data_reviews)
    wordOccurencesPositive, wordOccurencesNegative = task3(task3words, training_data_reviews, training_labels)
    task4(wordOccurencesPositive, wordOccurencesNegative)





main()